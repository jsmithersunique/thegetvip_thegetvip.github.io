<?php  
include 'common.php';
sayyes();   // prints sever vars in an HTML comment so view source on the page
getxapps();  // API to Wowza works - this gets list of named app on server
?>
<!DOCTYPE html> 
<meta charset="UTF-8">
<html>  
    <head>
        <title>Innoc.us - TV from your event</title>
    <script src="webrtc.js"></script>
        <link rel="shortcut icon" href="vidfav.png" />
        <link rel="icon" type="image/png" href="vidfav.png" />
    </head>
    <body style="background:url(u.jpg) no-repeat; margin-left:auto; margin-right:auto; align:center; text-align:center; background-size:100% auto;
                 font-family:verdana,helvetica,swiss;font-size:10pt;color:lightblue;">
    <center>    
    <table align="center" width="85%" cellpadding="15"  border="0">
     <tr>
        <td width="20%">&nbsp;</td>
           <td width="60%">&nbsp;
        <video id="localVideo" autoplay muted style="width:740px;"></video>

        <br /><br />
    <center><input style="" type="button" id="start" onclick="start(true)" value="Start Streaming Your Cam Now"></input></center>
</td>
   <td width="20%">&nbsp;</td>
</tr>
<tr>
<td align="center" colspan="3">
<img src="tv.jpg" width="15%"/>&nbsp;
    <img src="tv.jpg" width="15%"/>&nbsp; 
    <img src="tv.jpg" width="15%"/>&nbsp; 
    <img src="tv.jpg" width="15%"/>&nbsp; 
    <img src="tv.jpg" width="15%"/><br />
    <span style="text-shadow: 1px 1px #444444;">Touch or click a video to move it to the main feed.</span>
    </td>
        </tr>
        </table></center>
        <script type="text/javascript">
            pageReady();
        </script>

		<div>
			<span id="sdpDataTag">
			</span>
		</div>
    </body>
</html>

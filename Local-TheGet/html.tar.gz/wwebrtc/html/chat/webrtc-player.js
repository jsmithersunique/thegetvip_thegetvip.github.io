var WebRTCPlayer = function(streamName)
{
	this.remoteVideo = null;
	this.peerConnection = null;
	this.peerConnectionConfig = ICE_SERVERS;
	this.postURL = SERVER_URL;
	this.streamInfo = {applicationName:WOWZA_APPLICATION_NAME, streamName:WOWZA_STREAM_NAME, sessionId:WOWZA_SESSION_ID_EMPTY};
	this.streamInfo.streamName = streamName;
};

WebRTCPlayer.prototype.sendPost = function(url, params)
{
	var http = new XMLHttpRequest();

	http.open("POST", url, true);

	http.setRequestHeader("Content-Length", params.length);
	http.setRequestHeader("Connection", "close");
	http.setRequestHeader("Accept", "text/plain");
	http.setRequestHeader("Content-Type", "text/plain");

	var self = this;

	http.onreadystatechange = function()
	{
    	console.log('http.readyState:'+http.readyState+'  http.status:'+http.status);
		if(http.readyState == 4 && http.status == 200)
		{
	    	console.log(http.responseText);

			var theAnswerJSON = JSON.parse(http.responseText);

    		var streamInfoResponse = theAnswerJSON['streamInfo'];
    		if (streamInfoResponse !== undefined)
    		{
				self.streamInfo.sessionId = streamInfoResponse.sessionId;
			}

    		var sdpData = theAnswerJSON['sdp'];
    		if (sdpData !== undefined)
    		{
    			console.log('sdp: '+theAnswerJSON['sdp']);

				self.peerConnection.setRemoteDescription(new RTCSessionDescription(theAnswerJSON.sdp), function() {
					self.peerConnection.createAnswer(function(description) {

							console.log('got description');

							self.peerConnection.setLocalDescription(description,
								function () {

									console.log('sendAnswer');

									self.sendPost(postURL, '{"direction":"play", "command":"sendResponse", "streamInfo":'+JSON.stringify(self.streamInfo)+', "sdp":'+JSON.stringify(description)+'}');

									},
								function() {

									console.log('set description error')
									}
								);
						}, self.errorHandler);
				}, self.errorHandler);
			}

    		var iceCandidates = theAnswerJSON['iceCandidates'];
    		if (iceCandidates !== undefined)
    		{
				for(var index in iceCandidates)
				{
     				console.log('iceCandidates: '+iceCandidates[index]);

       				self.peerConnection.addIceCandidate(new RTCIceCandidate(iceCandidates[index]));
				}
			}
		}
	}

	http.send(params);
};

WebRTCPlayer.prototype.shutdown = function()
{
	if (this.peerConnection != null)
		this.peerConnection.close();
	this.peerConnection = null;
}

WebRTCPlayer.prototype.start = function()
{
    this.remoteVideo = document.getElementById('video'+this.streamInfo.streamName);

    var self = this;

    this.peerConnection = new RTCPeerConnection(this.peerConnectionConfig);

    this.peerConnection.onicecandidate = function(event) {
		};

    this.peerConnection.onaddstream = function(event) {
		console.log('got remote stream');
		self.remoteVideo.src = window.URL.createObjectURL(event.stream);
		};

	console.log("postURL: "+this.postURL);

	this.sendPost(this.postURL, '{"direction":"play", "command":"getOffer", "streamInfo":'+JSON.stringify(this.streamInfo)+'}');
};

WebRTCPlayer.prototype.errorHandler = function(error)
{
    console.log(error);
};

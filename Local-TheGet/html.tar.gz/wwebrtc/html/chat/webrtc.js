var localVideo = null;
var peerConnection = null;
var peerConnectionConfig = ICE_SERVERS;
var postURL = SERVER_URL;
var streamInfo = {applicationName:WOWZA_APPLICATION_NAME, streamName:WOWZA_STREAM_NAME, sessionId:WOWZA_SESSION_ID_EMPTY};
var webrtcPlayers = [];
var myInterval = null;
var publishStreamName = null;

function pageReady()
{
    localVideo = document.getElementById('videoLOCALCAMERA');

    var constraints =
    {
        video: true,
        audio: true,
    };

    if(navigator.getUserMedia)
    {
        navigator.getUserMedia(constraints, getUserMediaSuccess, errorHandler);
    }
    else
    {
        alert('Your browser does not support getUserMedia API');
    }

    myInterval = setInterval(queryAvailableStreams, 3000);

    var cookieStreamName = $.cookie("webrtcDemoStreamName");
    if (cookieStreamName === undefined)
    {
		cookieStreamName = Math.floor((Math.random() * 2147483647) + 1);
		$.cookie("webrtcDemoStreamName", cookieStreamName);
	}
	console.log('cookieStreamName: '+cookieStreamName);

	$('#streamName').attr("value", cookieStreamName);
	$("#buttonPublish").attr('value', GO_BUTTON_JOIN);
}

function dotest(streamName)
{
	$("#video"+streamName).show();
}

function startPublisher()
{
	var streamName = $('#streamName').val();

	streamName = streamName.replace(/ /g, '');

	streamInfo.streamName = streamName;
	publishStreamName = streamName;

	peerConnection = new RTCPeerConnection(peerConnectionConfig);
	peerConnection.onicecandidate = gotIceCandidate;
	peerConnection.addStream(localStream);

	peerConnection.createOffer(gotDescription, errorHandler);

	$("#buttonPublish").attr('value', GO_BUTTON_LEAVE);
	$("#streamName").attr("disabled", true);
}

function stopPublisher()
{
	if (peerConnection != null)
		peerConnection.close();
	peerConnection = null;
	publishStreamName = null;

	$("#buttonPublish").attr('value', GO_BUTTON_JOIN);
	$("#streamName").attr("disabled", false);
}

function start()
{
	if (publishStreamName == null)
	{
		startPublisher();
	}
	else
	{
		stopPublisher();
	}
}

function queryAvailableStreams()
{
	sendPost(postURL, '{"direction":"publish", "command":"getAvailableStreams", "streamInfo":'+JSON.stringify(streamInfo)+'}');
}

function updateRunningStreams(availableStreams)
{
	var validStreams = [];
	var runningStreams = [];

	for(var index in webrtcPlayers)
	{
		runningStreams.push(index);
	}

	for(var index in availableStreams)
	{
		var streamName = availableStreams[index].streamName;
		var readyAudio = availableStreams[index].readyAudio;
		var readyVideo = availableStreams[index].readyVideo;
		var codecAudio = availableStreams[index].codecAudio;
		var codecVideo = availableStreams[index].codecVideo;

		while(true)
		{
			if (streamName == publishStreamName)
				break;

			if (!readyAudio && !readyVideo)
				break;

			if (readyVideo && !(codecVideo == CODEC_VIDEO_VPX))
				break;

			if (readyAudio && !(codecAudio == CODEC_AUDIO_OPUS || codecAudio == CODEC_AUDIO_VORBIS))
				break;

			var rindex = runningStreams.indexOf(streamName);
			if (rindex >= 0)
				runningStreams.splice(rindex, 1);

			startVideoPlayer(streamName);
			break;
		}
	}

	for(var index in runningStreams)
	{
		stopVideoPlayer(runningStreams[index]);
	}
}

function onPlayStart(streamName)
{
	$("#video"+streamName).show();
}

function startVideoPlayer(streamName)
{
	console.log('startVideoPlayer: '+streamName);
	if (webrtcPlayers[streamName] == undefined)
	{
		webrtcPlayers[streamName] = new WebRTCPlayer(streamName);

		$( '#videoContainer' ).append( '<video id="video'+streamName+'" onplay="onPlayStart(\''+streamName+'\')" autoplay style="height:288px;margin:5px;display:none;"></video>');

		webrtcPlayers[streamName].start();
	}
}

function stopVideoPlayer(streamName)
{
	console.log('stopVideoPlayer: '+streamName);
	if (webrtcPlayers[streamName] !== undefined)
	{
		webrtcPlayers[streamName].shutdown();
		delete webrtcPlayers[streamName];
		$( '#video'+streamName ).remove();
	}
}

function sendPost(url, params)
{
	var http = new XMLHttpRequest();

	http.open("POST", url, true);

	http.setRequestHeader("Content-Length", params.length);
	http.setRequestHeader("Connection", "close");
	http.setRequestHeader("Accept", "text/plain");
	http.setRequestHeader("Content-Type", "text/plain");

	http.onreadystatechange = function()
	{
    	console.log('http.readyState:'+http.readyState+'  http.status:'+http.status);

		if(http.readyState == 4)
		{
			if (http.status == 200)
			{
				console.log(http.responseText);

				var theAnswerJSON = JSON.parse(http.responseText);

				var commandStr = theAnswerJSON['command'];
				var status = theAnswerJSON['status'];
				var statusDescription = theAnswerJSON['statusDescription'];

				console.log('command['+status+']: '+commandStr+" :"+statusDescription);

				if (commandStr == "sendOffer")
				{
					if (status != 200)
					{
						stopPublisher();

						$("#statusMessages").text(statusDescription);
					}
					else
					{
						$("#statusMessages").text('');
					}
				}

				var sdpData = theAnswerJSON['sdp'];
				if (sdpData !== undefined)
				{
					console.log('sdp: '+theAnswerJSON['sdp']);

					peerConnection.setRemoteDescription(new RTCSessionDescription(sdpData), function() {
						//peerConnection.createAnswer(gotDescription, errorHandler);
					}, errorHandler);
				}

				var iceCandidates = theAnswerJSON['iceCandidates'];
				if (iceCandidates !== undefined)
				{
					for(var index in iceCandidates)
					{
						console.log('iceCandidates: '+iceCandidates[index]);

						peerConnection.addIceCandidate(new RTCIceCandidate(iceCandidates[index]));
					}
				}

				if (commandStr == "getAvailableStreams")
				{
					var availableStreams = theAnswerJSON['availableStreams'];
					if (availableStreams !== undefined)
					{
						updateRunningStreams(availableStreams);
					}
					else
					{
						updateRunningStreams([]);
					}
				}
			}
			else
			{
    			console.log('http.ERROR:'+http.statusText);
			}
		}
	}

	http.send(params);
}

function getUserMediaSuccess(stream)
{
    localStream = stream;
    localVideo.src = window.URL.createObjectURL(stream);
}

function gotIceCandidate(event)
{
    if(event.candidate != null)
    {
    	console.log('gotIceCandidate: '+JSON.stringify({'ice': event.candidate}));
    }
}

function gotDescription(description)
{
    console.log('gotDescription: '+JSON.stringify({'sdp': description}));

    peerConnection.setLocalDescription(description, function () {

        sendPost(postURL, '{"direction":"publish", "command":"sendOffer", "streamInfo":'+JSON.stringify(streamInfo)+', "sdp":'+JSON.stringify(description)+'}');

    }, function() {console.log('set description error')});
}

function errorHandler(error)
{
    console.log(error);
}

package com.wowza.wms.plugin.webrtc.http;

import java.io.*;
import java.util.*;

import com.wowza.util.*;
import com.wowza.wms.http.*;
import com.wowza.wms.logging.*;
import com.wowza.wms.plugin.webrtc.model.*;
import com.wowza.wms.vhost.*;

public class HTTPWebRTCExchangeSessionInfo extends HTTPProvider2Base
{
    private static final Class<HTTPWebRTCExchangeSessionInfo> CLASS = HTTPWebRTCExchangeSessionInfo.class;
	private static final String CLASSNAME = "HTTPWebRTCExchangeSessionInfo";
	
	public static final String MIMETYPE_JSON = "application/json";

	public static final String STRING_ENCODING = "UTF-8";

	public void onHTTPRequest(IVHost inVhost, IHTTPRequest req, IHTTPResponse resp)
	{
		StringBuffer responseStr = new StringBuffer();
		
		String queryStr = req.getQueryString();

        Map<String, String> queryMap = HTTPUtils.splitQueryStr(queryStr);

        String bodyBufferStr = null;
        byte[] msgBytes = req.getMsgBytes();
		if (msgBytes != null)
		{
			try
			{
				bodyBufferStr = new String(msgBytes, STRING_ENCODING);
				if (bodyBufferStr != null && bodyBufferStr.length() <= 0)
					bodyBufferStr = null;
			}
			catch (Exception e)
			{
				WMSLoggerFactory.getLogger(CLASS).error(CLASSNAME+".onHTTPRequest ", e);
			}
		}
		
		WebRTCCommandRequest commandRequest = null;
		if (bodyBufferStr != null)
			commandRequest = WebRTCCommandRequest.parseJSON(bodyBufferStr);
		
		if (commandRequest != null)
		{			
			WebRTCCommandResponse commandResponse = new WebRTCCommandResponse();
			
			boolean didCommand = true;

			String commandStr = commandRequest.getCommand();
			if (commandStr.equals("sendOffer"))
				WebRTCCommands.sendOffer(inVhost, commandRequest, commandResponse);
			else if (commandStr.equals("sendResponse"))
				WebRTCCommands.sendResponse(inVhost, commandRequest, commandResponse);
			else if (commandStr.equals("getOffer"))
				WebRTCCommands.getOffer(inVhost, commandRequest, commandResponse);
			else if (commandStr.equals("getAvailableStreams"))
				WebRTCCommands.getAvailableStreams(inVhost, commandRequest, commandResponse);
			else
			{
				didCommand = false;
				WMSLoggerFactory.getLogger(CLASS).warn(CLASSNAME+".onHTTPRequest: Missing command: "+commandStr);
			}
			
			if (didCommand)
				responseStr.append(commandResponse.toJSON());
		}

		if (responseStr.length() <= 0)
		{
			responseStr.append("{");
			responseStr.append("\"status\":"+WebRTCCommands.STATUS_APPLICATION_FAILURE+",");
			responseStr.append("\"statusDescription\":\""+"Application Failure"+"\"");
			responseStr.append("}");
		}
		
		//System.out.println("response:\n"+responseStr.toString());

		try
		{
			resp.setHeader("Content-Type", MIMETYPE_JSON);
			resp.setHeader("Access-Control-Allow-Credentials", "true");
			resp.setHeader("Access-Control-Expose-Headers", "Content-Length, Connection, Date");
			resp.setHeader("Access-Control-Allow-Methods", "PROPFIND, PROPPATCH, COPY, MOVE, DELETE, MKCOL, LOCK, UNLOCK, PUT, GETLIB, VERSION-CONTROL, CHECKIN, CHECKOUT, UNCHECKOUT, REPORT, UPDATE, CANCELUPLOAD, HEAD, OPTIONS, GET, POST");
			resp.setHeader("Access-Control-Allow-Headers", "Content-Length, Connection, Overwrite, Destination, Content-Type, Depth, User-Agent, X-File-Size, X-Requested-With, If-Modified-Since, X-File-Name, Cache-Control, Range");
			resp.setHeader("Access-Control-Allow-Origin", "*");
			resp.setHeader("Content-Type", "text/plain");
			
			OutputStream out = resp.getOutputStream();
			byte[] outBytes = responseStr.toString().getBytes(STRING_ENCODING);
			out.write(outBytes);
		}
		catch (Exception e)
		{
			WMSLoggerFactory.getLogger(CLASS).error(CLASSNAME+".onHTTPRequest ", e);
		}
	}
}

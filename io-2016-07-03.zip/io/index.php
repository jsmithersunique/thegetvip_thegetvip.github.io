<?php  
include 'common.php';
//sayyes();
?>
<!DOCTYPE html> 
<meta charset="UTF-8">
<html>
    <head>
        <script src="webrtc.js"></script>
    </head>

    <body style="background:url(u.jpg) no-repeat; margin-left:auto; margin-right:auto; align:center; text-align:center; background-size:100% auto;
                 font-family:verdana,helvetica,swiss;font-size:10pt;color:lightblue;">
    <table cellpadding="15"  border="0">
     <tr>
        <td width="33%">&nbsp;</td>
           <td width="33%">&nbsp;
        <video id="localVideo" autoplay muted style="width:740px;"></video>

        <br /><br />

    <center><input style="" type="button" id="start" onclick="start(true)" value="Start Streaming Now"></input></center>
</td>
   <td width="33%">&nbsp;</td>
</tr>
<tr>
<td colspan="3">
<img src="tv.jpg" width="15%"/>&nbsp;
    <img src="tv.jpg" width="15%"/>&nbsp; 
    <img src="tv.jpg" width="15%"/>&nbsp; 
    <img src="tv.jpg" width="15%"/>&nbsp; 
    <img src="tv.jpg" width="15%"/><br />
    Touch or click a video to move it to the main feed.
    </td>
</tr>
        <script type="text/javascript">
            pageReady();
        </script>

		<div>
			<span id="sdpDataTag">
			</span>
		</div>
    </body>
</html>
